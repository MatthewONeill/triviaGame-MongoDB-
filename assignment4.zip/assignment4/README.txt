Matthew O'Neill
101103900

1) Mongo Daemon should be running in the background
1.5) in cmd in the directory run npm install
2) node database-initilizer.js should be run before starting program

3) run node server.js in cmd once previous steps are completed

4) Navigate to localhost:3000/questions to get questions and add queries for categories and difficulties
5) Navigate to localhost:3000/questions/:qid to get specific question details
6) Navigate to localhost:3000/createQuiz to create a quiz
7) Press save quiz button to be redirected to your created quiz
8) Navigate to localhost:3000/quizzes to see all quizzes in the database and add queries for creator and tag
9) Navigate to localhost:3000/quiz/:quizID to see specific quiz details or click on any quiz in localhost:3000/quizzes